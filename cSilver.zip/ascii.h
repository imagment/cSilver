#ifndef MEMES_H
#define MEMES_H

const char* get_random_meme();

#endif 
