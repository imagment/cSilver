#ifndef GAME_LOGIC_H
#define GAME_LOGIC_H

char* art(const char* filename);

#endif 
