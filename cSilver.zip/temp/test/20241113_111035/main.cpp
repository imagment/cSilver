#include <iostream>

int main() {
    std::cout << "Hello, World!s" << std::endl;
    return 0;
}
