#include "compiler.h"

#include <stdio.h>

#include <stdlib.h>

#include <string.h>

#include <time.h>

#include <unistd.h>

#include <dirent.h>

#include <sys/stat.h>

#include <dlfcn.h>

#define ALLOWED_HEADER "silver.h"
#define MAX_CODE_LENGTH 3999
#define DAYS_LIMIT 2

#define MAX_LINE_LENGTH 8000
#define TEMP_FILE "compiled.c"
#define BACKUP_DIR "./temp/"
#define MAX_BACKUPS 10

int debugmode = 0, torchmode = 0;
char header_inclusions[MAX_LINE_LENGTH * 1000] = "";
int mode = 1;

int create_dir(const char * path) {
  char cmd[1024];
  snprintf(cmd, sizeof(cmd), "mkdir -p \"%s\"", path);
  return system(cmd);
}

void create_backup(const char * project_name) {
  char project_dir[1024];
  char backup_dir[1024];
  char timestamp[128];
  time_t now = time(NULL);
  struct tm * t = localtime( & now);

  snprintf(project_dir, sizeof(project_dir), "./projects/%s", project_name);

  struct stat st;
  if (stat(project_dir, & st) != 0 || !S_ISDIR(st.st_mode)) {
    printf("\033[0;31m[!] Project directory does not exist.\033[0m\n");
    return;
  }

  strftime(timestamp, sizeof(timestamp), "%Y%m%d_%H%M%S", t);
  snprintf(backup_dir, sizeof(backup_dir), "%s/%s/%s", BACKUP_DIR, project_name, timestamp);

  if (create_dir(backup_dir) != 0) {
    perror("Backup directory creation failed");
    return;
  }

  char command[2048];
  snprintf(command, sizeof(command),
    "find \"%s\" -type f -name '*.c' -exec bash -c 'cp \"{}\" \"%s/$(basename {} .c).c.temp\"' \\;",
    project_dir, backup_dir);
  int result = system(command);
  if (result != 0) {
    printf("\033[0;31m[!] Backup failed: File copy failed.\033[0m\n");
    return;
  }

  snprintf(command, sizeof(command),
    "find \"%s\" -type f ! -name '*.c' -exec cp {} \"%s/\" \\;",
    project_dir, backup_dir);
  result = system(command);
  if (result != 0) {
    printf("\033[0;31m[!] Backup failed: File copy failed.\033[0m\n");
    return;
  }

  snprintf(command, sizeof(command),
    "find \"%s/%s\" -maxdepth 1 -type d -name '20*' | sort | head -n -%d | xargs -r rm -rf",
    BACKUP_DIR, project_name, MAX_BACKUPS);
  result = system(command);
  if (result != 0) {
    printf("\033[0;31m[!] Backup management failed: Deleting old backups failed.\033[0m\n");
  }
}

void manage_backups() {
  DIR * d = opendir(BACKUP_DIR);
  if (d == NULL) {
    perror("Could not open backup directory");
    return;
  }

  char * backup_files[MAX_BACKUPS + 1];
  int backup_count = 0;

  struct dirent * dir;
  while ((dir = readdir(d)) != NULL) {
    if (dir -> d_type == DT_DIR && strstr(dir -> d_name, "20")) {
      if (backup_count < MAX_BACKUPS) {
        backup_files[backup_count] = strdup(dir -> d_name);
        backup_count++;
      } else {
        free(backup_files[MAX_BACKUPS]);
        backup_files[MAX_BACKUPS] = strdup(dir -> d_name);
      }
    }
  }
  closedir(d);

  qsort(backup_files, backup_count, sizeof(char * ), (int( * )(const void * ,
    const void * )) strcmp);

  for (int i = 0; i < backup_count - MAX_BACKUPS; ++i) {
    char rm_command[512];
    snprintf(rm_command, sizeof(rm_command), "rm -rf \"%s/%s\"", BACKUP_DIR, backup_files[i]);
    printf("[+] Running command: %s\n", rm_command);
    if (system(rm_command) == -1) {
      printf("\033[0;31m[!] Error executing command\033[0m\n");
    }
    free(backup_files[i]);
  }

  for (int i = backup_count - MAX_BACKUPS; i < backup_count; ++i) {
    free(backup_files[i]);
  }
}

void clear_screen() {
  #ifdef _WIN32
  system("cls");
  #else
  system("clear");
  #endif
}
char * read_with_replacement(const char * filename) {
  FILE * file = fopen(filename, "r");
  if (!file) {
    perror("Failed to open file");
    return NULL;
  }

  fseek(file, 0, SEEK_END);
  long length = ftell(file);
  fseek(file, 0, SEEK_SET);

  char * buffer = (char * ) malloc(length + 1);
  if (!buffer) {
    perror("Failed to allocate memory");
    fclose(file);
    return NULL;
  }

  fread(buffer, 1, length, file);
  buffer[length] = '\0';
  fclose(file);

  char * modified_content = (char * ) malloc(length * 2);
  if (!modified_content) {
    perror("Failed to allocate memory");
    free(buffer);
    return NULL;
  }

  char * src = buffer;
  char * dest = modified_content;
  int in_quotes = 0;

  while ( * src) {
    if ( * src == '"') {
      in_quotes = !in_quotes;
      * dest++ = * src++;
    } else if (!in_quotes && * src == ';') {
      * dest++ = '\n';
      src++;
    } else {
      * dest++ = * src++;
    }
  }
  * dest = '\0';

  free(buffer);
  return modified_content;
}
void unescape_string(char * dest,
  const char * src) {
  while ( * src) {
    if ( * src == '\\' && * (src + 1)) {
      src++;
      switch ( * src) {
      case 'n':
        *
        dest = '\n';
        break;
      case 't':
        *
        dest = '\t';
        break;
      case 'r':
        *
        dest = '\r';
        break;
      case '\\':
        *
        dest = '\\';
        break;
      case '\"':
        *
        dest = '\"';
        break;
      case '\'':
        *
        dest = '\'';
        break;
      case '0':
        *
        dest = '\0';
        break;
      default:
        *
        dest = * src;
        break;
      }
    } else {
      * dest = * src;
    }
    dest++;
    src++;
  }
  * dest = '\0';
}

int check_file_size(const char * file_path, size_t max_size) {
  FILE * file = fopen(file_path, "r");
  if (file == NULL) {
    perror("Error opening file");
    return -1;
  }

  fseek(file, 0, SEEK_END);
  long file_size = ftell(file);
  fclose(file);

  if (file_size == -1) {
    perror("Error getting file size");
    return -1;
  }

  return (file_size > (long) max_size) ? 1 : 0;
}

int check_no_external_includes(const char * file_path) {
  FILE * file = fopen(file_path, "r");
  if (file == NULL) {
    perror("Error opening file");
    return -1;
  }

  char line[256];
  while (fgets(line, sizeof(line), file)) {

    if (strncmp(line, "#include", 8) == 0) {

      char * start = strchr(line, '"');
      char * end = strrchr(line, '"');

      if (start != NULL && end != NULL && end > start) {

        char include_file[256];
        strncpy(include_file, start + 1, end - start - 1);
        include_file[end - start - 1] = '\0';

        char * ext = strrchr(include_file, '.');
        if (ext != NULL) {
          if (strcmp(ext, ".c") == 0 || strcmp(ext, ".cpp") == 0 ||
            strcmp(ext, ".cs") == 0 || strcmp(ext, ".hpp") == 0 ||
            strcmp(ext, ".h") != 0 || (strcmp(include_file, ALLOWED_HEADER) != 0 && strcmp(include_file, "silver.h") != 0)) {
            fclose(file);
            return 1;
          }
        }
      }
    }
  }
  fclose(file);
  return 0;
}
int check_time(const char * line) {

  struct tm file_time = {
    0
  };
  int year, month, day, hour, minute, second;
  if (sscanf(line, "%d-%d-%d %d:%d:%d\n", &
      year, & month, & day, & hour, & minute, & second) != 6) {
    fprintf(stderr, "Error parsing date and time\n");
    return -1;
  }

  file_time.tm_year = year - 1900;
  file_time.tm_mon = month - 1;
  file_time.tm_mday = day;
  file_time.tm_hour = hour;
  file_time.tm_min = minute;
  file_time.tm_sec = second;
  file_time.tm_isdst = -1;

  time_t file_time_t = mktime( & file_time);
  if (file_time_t == -1) {
    perror("Error converting time");
    return -1;
  }

  time_t current_time = time(NULL);
  if (current_time == -1) {
    perror("Error getting current time");
    return -1;
  }

  double seconds_diff = difftime(current_time, file_time_t);

  int days_diff = seconds_diff / (60 * 60 * 24);

  printf("File time: %ld, Current time: %ld, Seconds diff: %.0f, Days diff: %d\n",
    file_time_t, current_time, seconds_diff, days_diff);

  return days_diff >= 3 ? 1 : 0;
}

typedef void( * func_type)();

void compileC(const char * source_file,
  const char * mode) {

  if (strcmp(mode, "1") != 0) {

    if (check_file_size(source_file, 800) != 0) {
      printf("\033[0;31mUser is ugly\nExiting Program...\033[0m");
      sleep(1);
      exit(0);
      return;
    }
    if (check_no_external_includes(source_file) != 0) {
      printf("\033[0;31mIdiot have been detected\nExiting Program...\033[0m");
      sleep(1);
      exit(0);
      return;
    }
    if (check_time(mode) != 0) {
      printf("\033[0;31mYou were late. Therefore, you are ugly\nExiting Program...\033[0m");
      sleep(1);
      exit(0);
      return;
    }
  }

  char exec_file[256];
  snprintf(exec_file, sizeof(exec_file), "temp_exec");

  char command[512];
  snprintf(command, sizeof(command), "gcc -o %s %s", exec_file, source_file);
  system(command);

  snprintf(command, sizeof(command), "./%s", exec_file);
  system(command);

  remove(exec_file);
}
void runPy(const char * project_name) {
  char command[512];
  snprintf(command, sizeof(command), "python3 ./projects/%s/main.py", project_name);
  system(command);
}

void runRuby(const char * project_name) {
  char command[512];
  snprintf(command, sizeof(command), "ruby ./projects/%s/main.rb", project_name);
  system(command);
}

char * context = NULL;

char * read_file_content(const char * file_path) {
  FILE * file = fopen(file_path, "r");
  if (!file) {
    perror("Failed to open file");
    return NULL;
  }

  fseek(file, 0, SEEK_END);
  long file_size = ftell(file);
  fseek(file, 0, SEEK_SET);

  char * content = (char * ) malloc(file_size + 1);
  if (!content) {
    perror("Memory allocation error");
    fclose(file);
    return NULL;
  }

  fread(content, 1, file_size, file);
  content[file_size] = '\0';

  fclose(file);
  return content;
}

int has_file_changed(const char * file_path) {

  char * current_content = read_file_content(file_path);
  if (!current_content) {
    return 1;
  }

  int has_changed = (context == NULL || strcmp(context, current_content) != 0);

  if (context) {
    free(context);
  }
  context = current_content;

  return has_changed;
}

void execute_script(char * project_name, char * mode) {
  create_backup(project_name);
  char path[512];
  snprintf(path, sizeof(path), "./projects/%s/main.c", project_name);

  if (strcmp(mode, "1") == 0) {

    if (has_file_changed(path)) {
      compileC(path, "1");
      char command[512];
      snprintf(command, sizeof(command), "./projects/%s/a.out", project_name);
      int ret = system(command);
      if (ret != 0) {
        printf("Error executing command: %s\n", command);
      }
    } else {

      char command[512];
      snprintf(command, sizeof(command), "./projects/%s/a.out", project_name);
      int ret = system(command);
      if (ret != 0) {
        printf("Error executing command: %s\n", command);
      }
    }
    return;
  } else if (strcmp(mode, "4") == 0) {
    char cwd[1024];
    if (getcwd(cwd, sizeof(cwd)) == NULL) {
      perror("getcwd() error");
      return;
    }

    char scriptPath[1024];
    snprintf(scriptPath, sizeof(scriptPath), "%s/projects/%s/main.tc", cwd, project_name);
    char command[2048];
    snprintf(command, sizeof(command), "tuch \"%s\"", scriptPath);

    int ret = system(command);
    if (ret != 0) {
      printf("Error executing command: %s\n", command);
    }
    return;
  } else if (strcmp(mode, "5") == 0) {
    runPy(project_name);
    return;
  } else if (strcmp(mode, "6") == 0) {
    runRuby(project_name);
    return;
  } else if (strcmp(mode, "7") == 0) {
    snprintf(path, sizeof(path), "./projects/%s/main.rs", project_name);
    char command[512];
    snprintf(command, sizeof(command), "rustc %s -o ./projects/%s/a.out", path, project_name);
    int ret = system(command);
    if (ret != 0) {
      printf("Error executing command: %s\n", command);
    }
    snprintf(command, sizeof(command), "./projects/%s/a.out", project_name);
    ret = system(command);
    if (ret != 0) {
      printf("Error executing command: %s\n", command);
    }
    return;
  } else if (strcmp(mode, "2") == 0) {
    snprintf(path, sizeof(path), "./projects/%s/main.cpp", project_name);

    struct stat file_stat;
    if (stat(path, & file_stat) != 0) {
      printf("File does not exist: %s\n", path);
      return;
    }

    if (has_file_changed(path)) {
      char command[512];
      snprintf(command, sizeof(command), "g++ %s -o ./projects/%s/a.out", path, project_name);

      int ret = system(command);
      if (ret != 0) {
        printf("Error compiling C++ code: %s\n", command);
      }
    }

    char command[512];
    snprintf(command, sizeof(command), "./projects/%s/a.out", project_name);

    int ret = system(command);
    if (ret != 0) {
      printf("Error executing a.out: %d\n", ret);
    }
    return;
  } else if (strcmp(mode, "0") == 0) {
    snprintf(path, sizeof(path), "./projects/%s/main.txt", project_name);
    char command[512];
    snprintf(command, sizeof(command), "cat %s", path);
    int ret = system(command);
    if (ret != 0) {
      printf("Error executing command: %s\n", command);
    }
    return;
  } else {
    compileC(path, mode);
    return;
  }
}
