#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "ascii.h"

#define MAX_ART_SIZE 1024 
static const char* memes[] = {
    "\033[1;33m⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿\n⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿\n⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿\n⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿\n⣿⣿⣿⣿⡋⣹⣿⣿⣿⣿⣿⣿⣿⣏⠉⣿⣿⣿⣿⣿\n⣿⣿⣿⣿⣿⣿⣿⠹⣿⣿⡿⠏⣿⣿⣿⣿⣿⣿⣿⣿\n⣿⣿⣿⣿⣿⣿⣿⣷⣶⣶⣶⣿⣿⣿⣿⣿⣿⣿⣿⣿\n⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿\n⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿\n⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿\n⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿\n\033[35mHa Ha your code is screwed\033[0m\n\n",
    "\n\033[1;32mAlright, grab some coffee\n"
    "(  )   (   )  )\n"
    " ) (   )  (  (\n"
    "( )  (    ) )\n"
    " ______________\n"
    "<_____________ >___\n"
    "|             |/ _ \\\n"
    "|               | | |\n"
    "|               |_| |\n"
    "|             |\\___/\n"
    "|             |    \n"
    "\\____________/\033[0m\n\n",
    "\n\033[1;34mTry joining our discord! : https://discord.gg/72TbP8G69k\n(Or you will have a curse that you will misspell a name of a variable.)\033[0m\n\n",
    
  "\n\033[34mSilver is not pricier than gold, but that doesn't mean silver is worthless. \033[0m\n"
      "\033[1;38;5;239m⠀     ⠀⠀⠠⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣰⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n"
      "⠀⠀⠀⠀⠀⠀⠀⠀⣿⣷⣦⡀⠀⠀⠀⠀⣠⡾⠟⠿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n"
      "⠀⠀⠀⠀⠀⠀⠀⠀⢸⣿⣿⣿⣷⣄⠀⠘⢁⣠⣶⣦⣄⡀⠀⠀⠀⠀⠀⠀⠀⠀\n"
      "⠀⠀⠀⠀⠀⠀⠀⠀⠈⣿⠿⠛⢉⣠⣴⣾⣿⣿⣿⣿⠿⠻⢶⣤⣀⠀⠀⠀⠀⠀\n"
      "⠀⠀⠀⠀⠀⠀⠀⠀⢀⣡⣴⣾⣿⣿⣿⣿⠿⠛⠉⣀⣤⡶⠟⢋⣁⣤⠀⠛⠀⠀\n"
      "⠀⠤⣴⡖⠈⣠⣴⡾⠛⠻⢿⣿⠿⠛⠉⣀⣤⣶⠟⠋⣁⣤⣾⣿⣿⣿⣇⠀⠀⠀\n"
      "⠀⠀⠀⠁⣤⣈⠙⠻⢷⣦⣀⢀⣠⣴⠿⠛⢉⣠⣴⣿⣿⣿⣿⣿⣿⡿⠛⠀⠀⠀\n"
      "⠀⠀⠀⣸⣿⣿⣿⣶⣤⣈⠙⠛⢉⣠⣴⣾⣿⣿⣿⣿⣿⡿⠟⠋⠁⠀⠀⠀⠀⠀\n"
      "⠀⠀⠀⢿⣿⣿⣿⣿⣿⣿⡇⢰⣿⣿⣿⣿⣿⡿⠟⠋⣁⣤⣶⣿⣦⡀⠀⠀⠀⠀\n"
      "⠀⠀⠀⠀⠈⠙⠻⢿⣿⣿⡇⢸⣿⡿⠟⠋⣁⣤⣶⠛⠛⠿⠿⢿⣿⣷⡄⠀⠀⠀\n"
      "⠀⠀⠀⠀⠀⢀⣶⣄⡈⠛⠃⠘⠉⠠⣴⣾⣿⣿⡇⠀⠀⠀⠀⠀⠀⠀⠉⠀⠀⠀\n"
      "⠀⠀⠀⠀⠀⠘⠉⠀⠀⠀⠀⠀⠀⠀⠹⣿⣿⣿⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n"
      "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠘⣿⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\033[0m\n"
        
         "\n\nThank you for using this program.\n\n\033[31mMade by\nImagment Studios\ntynw_   .wincat   peterkim922   and dhwlgh_\033[0m\n\n" 

};


#define NUM_MEMES (sizeof(memes) / sizeof(memes[0]))

const char* get_random_meme() {
    srand((unsigned int)time(NULL));
    int index = rand() % NUM_MEMES; 
    
    srand((unsigned int)time(NULL));
    if(index==3 && rand()%100!=1) index=rand()%3;
    
    return memes[index];
    
}

