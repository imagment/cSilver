sudo ln -s "$(pwd)/Tuchtig" /usr/local/bin/tuch
tuch --version
